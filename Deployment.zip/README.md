# ChatSystem

Pour déployer :

1) Extraire le dossier turbo9000 (qui se trouve dans l'archive Deployment.zip) dans la destination souhaitée
2) Configurer les fichiers client.properties et server.properties
3) Lancer le server et/ou le client avec les script .sh pour linux ou .bat pour windows
