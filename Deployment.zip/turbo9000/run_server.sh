java -jar Turbo9000.jar server
